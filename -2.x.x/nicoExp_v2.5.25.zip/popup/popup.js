var cs = document.getElementById('click-scroll');//--------
var dl = document.getElementById('draw-link');//--------
var dj = document.getElementById('draw-jid');//
var ld = document.getElementById('link-div');//--------
var jd = document.getElementById('jid-div');//jump id

document.getElementById('view-version').innerHTML = "version-"+chrome.runtime.getManifest().version;

document.addEventListener('DOMContentLoaded', function () {
    chrome.storage.sync.get({
        click_scroll: 2,
        draw_link: true,
        draw_jid: true
    },
        items => {
            cs.value = items.click_scroll;
            dl.checked = items.draw_link;
            dj.checked = items.draw_jid;
            if (dl.checked) {
                ld.style.display = "inline";
            } else {
                ld.style.display = "none";
            }
            if (dj.checked) {
                jd.style.display = "inline";
            } else {
                jd.style.display = "none";
            }
            chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
                chrome.tabs.sendMessage(tabs[0].id, { type: 'cs', cs_value: cs.value });
            });
        });

    cs.addEventListener('change', e => {
        chrome.storage.sync.set({ click_scroll: cs.value });
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
            chrome.tabs.sendMessage(tabs[0].id, { type: 'cs', cs_value: cs.value });
        });
        return false;
    });
    dl.addEventListener('change', e => {
        chrome.storage.sync.set({ draw_link: dl.checked });
        if (dl.checked) {
            ld.style.display = "inline";
        } else {
            ld.style.display = "none";
        }
        return false;
    });
    dj.addEventListener('change', e => {
        chrome.storage.sync.set({ draw_jid: dj.checked });
        if (dj.checked) {
            jd.style.display = "inline";
        } else {
            jd.style.display = "none";
        }
        return false;
    });
});

//==========================================================================

document.getElementById('id-jump').onclick = function () {
    id_jump(document.getElementById('id-in').value);
}
document.getElementById('id-in').addEventListener('keydown', e => {
    if (e.keyCode == 13) {
        id_jump(document.getElementById('id-in').value);
    }
});
function id_jump(id) {
    var url = id_to_url(id)
    if (url != -1) {
        window.open(url);
    }
}
function id_to_url(id) {
    if (id.match(/(sm|nm)\d+/)) {
        return "https://www.nicovideo.jp/watch/" + id + "?ref=nicoEx";
    } else if (id.match(/im\d+/)) {
        return "https://seiga.nicovideo.jp/seiga/" + id +"?track=nicoEx";
    } else if (id.match(/(lv|ch)\d+/)) {
        return "https://live.nicovideo.jp/watch/" + id + "?ref=nicoEx";
    } else if (id.match(/nc\d+/)) {
        return "https://commons.nicovideo.jp/material/" + id + "?transit_from=nicoEx";
    } else if (id.match(/td\d+/)) {
        return "https://3d.nicovideo.jp/works/" + id;
    } else if (id.match(/gm\d+/)) {
        return "https://game.nicovideo.jp/atsumaru/games/" + id + "?link_in=nicoEx";
    } else if (id.match(/nq\d+/)) {
        return "https://q.nicovideo.jp/watch/" + id;
    } else if (id.match(/nw\d+/)) {
        return "https://news.nicovideo.jp/watch/" + id + "?news_ref=nicoEx";
    } else if (id.match(/user\/\d+/)) {
        return "https://www.nicovideo.jp/" + id;
    }
    return -1;
}

document.getElementById('keyword-nico').onclick = function () {
    searcher_nico("https://nicovideo.jp/search/");
}
document.getElementById('tag-nico').onclick = function () {
    searcher_nico("https://nicovideo.jp/tag/");
}
document.getElementById('dic-nico').onclick = function () {
    searcher_nico("https://dic.nicovideo.jp/a/");
}
function searcher_nico(link_parts) {
    chrome.tabs.query({ active: true, currentWindow: true }, e => {
        var act_url = e[0].url;
        var act_host = act_url.split('/')[2];
        var search_word = "";
        if (act_host == "www.google.com") {
            search_word = new URLSearchParams(act_url.slice(act_url.indexOf('?'))).get("q");
        } else if (act_host == "www.youtube.com") {
            search_word = new URLSearchParams(act_url.slice(act_url.indexOf('?'))).get("search_query");
        } else {
            search_word = (new URLSearchParams(act_url.split('/').pop().split('?')[0]) + []).slice(0, -1);
        }
        window.open(link_parts + search_word);
    })
}